<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 col-md-offset-3">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">
                    Create article
                </h3>
            </div>
            <div class="panel-body">
                <form action="/articles" method="POST">

                	<input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">


                    <div class="form-group">
                        <label for="content">
                            Content
                        </label>
                        <textarea class="form-control" id="input" name="content" required="required" rows="3">
                        </textarea>
                    </div>
                    <div class="checkbox">
                        <label>
                        	<input name="live" id="id" type="checkbox" checked="checked">
                                Live
                            </input>
                        </label>
                    </div>
                    <div class="form-group">
                        <label for="posted_on">
                            Posted On
                        </label>
                        <input class="form-control" id="" name="posted_on" placeholder="Input field" type="datetime-local">
                        </input>
                    </div>
                    <input class="btn btn-success pull-right" name="" type="submit">
                    </input>
            		<?php echo e(csrf_field()); ?>

                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>