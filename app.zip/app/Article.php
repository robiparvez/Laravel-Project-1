<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Article extends Model
{

    protected $fillable = ['user_id', 'content', 'live', 'posted_on'];

    // protected $gaurded = ['id'];

    protected function setLiveAttribute($value)
    {
        $this->attributes['live'] = (boolean) $value;
    }

    protected function getShortContentAttribute($value = '')
    {
        return substr($this->content, 0, random_int(60, 150)).'...';
    }
}
