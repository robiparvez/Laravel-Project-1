<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Article;

class ArticlesController extends Controller
{
    public function index()
    {
        // Elequoent model(slower,nice)

        $articles = Article::paginate(5); //to show all data from database table, all(), then, used paginate() method
        return view('articles.index', compact('articles'));

    }

    public function create()
    {
        return view('articles.create');
    }

    public function store(Request $request)
    {

        Article::create($request->all()); //THIS IS PREFERABLE AND EASYYYYYYYYYY

    }

    public function show($id)
    {
        $article_id = Article::findorFail($id);
        // return $article_id;

        return view('articles.show', compact('article_id'));;
    }

    public function edit($id)
    {
    }

    public function update(Request $request, $id)
    {
    }

    public function destroy($id)
    {
        //
    }
}
