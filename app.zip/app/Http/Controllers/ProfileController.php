<?php
namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;
use Carbon;

class ProfileController extends Controller
{
    public function index($username)
    {
        $user = User::where('username', '=', $username)->first();

        // $age = Carbon\Carbon::createFromFormat()->age;
        // dd($user);

        return view('user.profile', compact('user','age'));
    }

    public function create()
    {


    }

    public function store(Request $request)
    {
    }
    public function show($id)
    {
    }
    public function edit($id)
    {
    }
    public function update(Request $request, $id)
    {
    }
    public function destroy($id)
    {
    }
}