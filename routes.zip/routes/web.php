<?php

Route::get('/', function ()
{
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index');

Route::get('/profile/{username}', 'ProfileController@index');

Route::resource('articles', 'ArticlesController');


Route::get('users/{id}', function() {

});
