@extends('layouts.app')



@section('content')
<div class="row">
    <div class="col-md-6 col-md-offset-3">
        <div class="panel panel-default">
            <div class="panel-heading">
                <span style="color: #8c2b36">
                   Article by: User ID ({{ $article_id->user_id }})
                </span>
                <span class="pull-right clearfix">
                    {{ $article_id->created_at->diffForHumans()}}
                </span>
            </div>
            <div class="panel-body">
                <span>
                    {{ $article_id->content }}
                </span>
            </div>
        </div>
    </div>
</div>
@stop
