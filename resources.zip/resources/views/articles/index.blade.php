@extends('layouts.app')



@section('content')
<div class="row">
    @forelse ($articles as $article)
    <div class="col-md-6 col-md-offset-3">
        <div class="panel panel-default">
            <div class="panel-heading">
                <span style="color: #8c2b36">
                    User ID: {{ $article->user_id }}
                </span>
                ({{ $article->created_at->diffForHumans() }})
                <span>
                </span>
            </div>
            <div class="panel-body">
                {{ $article->shortContent }}
                <a href="/articles/{{ $article->id }}">
                    Read More
                </a>
            </div>
            <div class="panel-footer clearfix" style="background-color: white">
                <i class="fa fa-heart pull-right">
                </i>
            </div>
        </div>
    </div>
    @empty
                No articles
        @endforelse
</div>
<div class="row">
    <div class="col-md-6 col-md-offset-3">
        {{ $articles->links() }}
    </div>
</div>
@stop
