@extends('layouts.app')
<style type="text/css">
    .profile-image{

	max-width: 150px;
	border: 5px solid #fff;
	border-radius: 100%;
	box-shadow: 0 2px 2px rgba(0,0,0,0.3);
}
</style>
@section('content')
<div class="row">
    <div class="col-md-6 col-md-offset-3">
        <div class="panel panel-default">
            <div class="panel-body text-center">
                <img class="profile-image" height="default" src="https://www.gepi.co/assets/img/profile_avatar.jpg" width="default">
                    <h1>
                        {{ $user->name }}
                    </h1>
                    <h5>
                        {{ $user->email }}
                    </h5>
                    <h5>
                        {{ $user->dob->format('l j F Y')}} ( {{ $user->dob->age }} years old)
                    </h5>


                  	<button type="button" class="btn btn-primary">Follow</button>
                </img>
            </div>
        </div>
    </div>
</div>
@stop
